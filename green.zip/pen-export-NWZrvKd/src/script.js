// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: "AIzaSyD81zEvo82IcEYZOT3lFyj7YJc9UyxEv4Y",
authDomain: "green-ride-d945a.firebaseapp.com",
  projectId: "green-ride-d945a",
 storageBucket: "green-ride-d945a.appspot.com",
 messagingSenderId: "546731730726",
 appId: "1:546731730726:web:87ef53a5634b7cdc9943e7",
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Firestore
var db = firebase.firestore();
document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    firebase.auth().signInWithEmailAndPassword(email, password)
        .then((userCredential) => {
            document.getElementById('login-page').style.display = 'none';
            document.getElementById('sales-log').style.display = 'block';
        })
        .catch((error) => {
            alert(error.message);
        });
});

document.getElementById('sales-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const plantName = document.getElementById('plant-name').value;
    const amount = parseFloat(document.getElementById('amount').value);
    const pricePerItem = parseFloat(document.getElementById('price-per-item').value);
    const totalPrice = amount * pricePerItem;
    const plantPhoto = document.getElementById('plant-photo').files[0];
    const customerName = document.getElementById('customer-name').value;
    const telephoneNumber = document.getElementById('telephone-number').value;

    const reader = new FileReader();
    reader.onload = function(e) {
        const saleItem = {
            plantName,
            amount,
            pricePerItem,
            totalPrice,
            plantPhoto: e.target.result,
            customerName,
            telephoneNumber,
            date: new Date().toISOString().split('T')[0]
        };

        db.collection("sales").add(saleItem)
            .then((docRef) => {
                alert("Sale logged successfully!");
                document.getElementById('sales-form').reset();
                updateSalesList();
            })
            .catch((error) => {
                alert("Error adding sale: " + error);
            });
    };
    reader.readAsDataURL(plantPhoto);
});

function updateSalesList() {
    const salesList = document.getElementById('sales-list');
    salesList.innerHTML = '';

    db.collection("sales").orderBy("date", "desc").get().then((querySnapshot) => {
        let total = 0;
        querySnapshot.forEach((doc) => {
            const sale = doc.data();
            total += sale.totalPrice;

            const saleItem = document.createElement('div');
            saleItem.className = 'sale-item';

            saleItem.innerHTML = `
                <h3>${sale.plantName}</h3>
                <p>Amount: ${sale.amount}</p>
                <p>Price per Item: $${sale.pricePerItem.toFixed(2)}</p>
                <p>Total Price: $${sale.totalPrice.toFixed(2)}</p>
                <p>Customer Name: ${sale.customerName}</p>
                <p>Telephone Number: ${sale.telephoneNumber}</p>
                <p>Date Sold: ${sale.date}</p>
                <img src="${sale.plantPhoto}" alt="Plant photo" style="max-width: 100px;">
            `;

            salesList.appendChild(saleItem);
        });

        const totalSales = document.getElementById('total-sales');
        totalSales.innerText = `Total Sales for Today: $${total.toFixed(2)}`;
    });
}

firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        document.getElementById('login-page').style.display = 'none';
        document.getElementById('sales-log').style.display = 'block';
        updateSalesList();
    } else {
        document.getElementById('login-page').style.display = 'block';
        document.getElementById('sales-log').style.display = 'none';
    }
});
